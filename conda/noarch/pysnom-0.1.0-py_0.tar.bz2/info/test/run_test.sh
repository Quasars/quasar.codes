

set -ex



python -m unittest pySNOM.tests
exit 0
