print("import: 'pySNOM'")
import pySNOM

